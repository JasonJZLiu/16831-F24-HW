The commands with the associated hyperparameters to reproduce the results presented in the submission
are included in the form of bash scripts in the rob831 folder. Specifically, 1.3.sh reproduces the 
BC results for Ant-v2 and Hopper-v2. 1.4.sh reproduces the Ant-v2 results where the learning rate
is varied. 2.1.sh reproduces the DAgger results for Ant-v2 and Hopper-v2.